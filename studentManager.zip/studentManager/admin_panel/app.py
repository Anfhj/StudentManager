from flask import Flask, render_template, request, redirect
import requests

app = Flask(__name__)
MAIN_SERVER = 'http://127.0.0.1:5000'

@app.route('/', methods=['GET', 'POST'])
def index():
    students = requests.get(f'{MAIN_SERVER}/get_all_students').json()

    if request.method == 'POST':
        action = request.form.get('action')
        student_key = request.form.get('student_key')
        allowed_sites = request.form.get('allowed_sites', '')
        allowed_sites_list = [site.strip() for site in allowed_sites.split(',') if site.strip()]

        if action == 'register':
            requests.post(f'{MAIN_SERVER}/register', json={'student_key': student_key})

        elif action == 'lock':
            requests.post(f'{MAIN_SERVER}/update_status', json={
                'student_key': student_key,
                'locked': True,
                'allowed_sites': allowed_sites_list
            })

        elif action == 'unlock':
            requests.post(f'{MAIN_SERVER}/update_status', json={
                'student_key': student_key,
                'locked': False,
                'allowed_sites': allowed_sites_list
            })

        elif action == 'lock_all':
            requests.post(f'{MAIN_SERVER}/lock_all')

        elif action == 'unlock_all':
            requests.post(f'{MAIN_SERVER}/unlock_all')

        return redirect('/')

    return render_template('index.html', students=students)

if __name__ == '__main__':
    app.run(port=5001, debug=True)