let studentKey = "";
let locked = false;
let allowedSites = [];

async function fetchStatus() {
    if (!studentKey) return;

    try {
        const response = await fetch(`http://127.0.0.1:5000/get_status/${studentKey}`);
        const data = await response.json();

        if (data && !data.error) {
            allowedSites = data.allowed_sites || [];
            const newLocked = data.locked || false;

            if (newLocked !== locked) {
                locked = newLocked;
                updateRules();
            }
        }
    } catch (error) {
        console.error("Failed to fetch status:", error);
    }
}

function urlToFilter(url) {
    return { urlFilter: url, resourceTypes: ["main_frame"] };
}

async function updateRules() {
    const session = chrome.declarativeNetRequest;

    const rules = [];

    if (locked) {
        rules.push({
            id: 1,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*", resourceTypes: ["main_frame"] }
        });

        let ruleId = 2;
        allowedSites.forEach(site => {
            rules.push({
                id: ruleId++,
                priority: 1,
                action: { type: "allow" },
                condition: {
                    urlFilter: site,
                    resourceTypes: ["main_frame"]
                }
            });
        });
    }

    await session.updateDynamicRules({
        removeRuleIds: Array.from({ length: 1000 }, (_, i) => i + 1),
        addRules: rules
    });
}

async function init() {
    const res = await chrome.storage.local.get("studentKey");
    if (res.studentKey) {
        studentKey = res.studentKey;
        await fetchStatus();
        setInterval(fetchStatus, 5000);
    }
}

init();
