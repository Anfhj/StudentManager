
document.getElementById("saveKey").addEventListener("click", async () => {
    const key = document.getElementById("studentKeyInput").value.trim();
    if (!key) return;

    await chrome.storage.local.set({ studentKey: key });
    document.getElementById("status").innerText = "Key saved. Reloading...";
    chrome.runtime.reload();
});
