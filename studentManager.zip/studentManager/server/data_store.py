students = {}
messages = {}

def register_student(student_key):
    if student_key not in students:
        students[student_key] = {'allowed_sites': [], 'locked': False}
        messages[student_key] = {'admin_to_student': [], 'student_to_admin': []}
        return True
    return False

def update_access(student_key, allowed_sites, locked):
    if student_key in students:
        students[student_key]['allowed_sites'] = allowed_sites
        students[student_key]['locked'] = locked
        return True
    return False

def get_status(student_key):
    return students.get(student_key, None)

def add_message(sender, recipient_key, message):
    if recipient_key in messages:
        if sender == "admin":
            messages[recipient_key]['admin_to_student'].append(message)
        else:
            messages[recipient_key]['student_to_admin'].append(message)

def get_messages(student_key):
    return messages.get(student_key, {'admin_to_student': [], 'student_to_admin': []})