from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# In-memory database
students = {}

@app.route('/register', methods=['POST'])
def register_student():
    data = request.get_json()
    key = data.get("student_key")
    if not key:
        return jsonify({"error": "Missing student_key"}), 400

    if key not in students:
        students[key] = {
            "locked": False,
            "allowed_sites": []
        }

    return jsonify({"status": "registered", "student_key": key})

@app.route('/get_status/<student_key>', methods=['GET'])
def get_status(student_key):
    if student_key not in students:
        return jsonify({"error": "not found"}), 404

    return jsonify(students[student_key])

@app.route('/update_status', methods=['POST'])
def update_status():
    data = request.get_json()
    key = data.get("student_key")

    if key not in students:
        return jsonify({"error": "not found"}), 404

    # Update locked and allowed_sites if present
    if "locked" in data:
        students[key]["locked"] = data["locked"]
    if "allowed_sites" in data:
        students[key]["allowed_sites"] = data["allowed_sites"]

    return jsonify({"status": "updated", "student_key": key})

# Fetch all students' information for the Admin Panel
@app.route('/get_all_students', methods=['GET'])
def get_all_students():
    return jsonify(students)

# Lock all students
@app.route('/lock_all', methods=['POST'])
def lock_all_students():
    for student in students.values():
        student["locked"] = True
    return jsonify({"status": "all students locked"})

# Unlock all students
@app.route('/unlock_all', methods=['POST'])
def unlock_all_students():
    for student in students.values():
        student["locked"] = False
    return jsonify({"status": "all students unlocked"})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
